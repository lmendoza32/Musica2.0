package com.example.musica20

import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    var mispotify: MediaPlayer?null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var botonPlay = findViewById<Button>(R.id.buttonPlay) as Button
        var botonStop = findViewById<Button>(R.id.buttonStop) as Button

        botonPlay.setOnClickListener {
            playSound()
        }
        botonStop.setOnClickListener {
            stopSound()
        }
    }
    fun playSound()
    {
        mispotify = MediaPlayer.create(this, Uri.parse("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"))
        try {
            mispotify!!.start()
        }catch (e:java.lang.Exception)

        {
            e.printStackTrace()
        }
    }
    fun stopSound()
    {
        if(mispotify!=null)
        {
            mispotify!!.stop()
            mispotify!!.release()
            mispotify=null
        }
    }
}